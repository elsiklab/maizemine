package org.intermine.bio.dataconversion;

/*
 * Copyright (C) 2002-2021 FlyMine
 *
 * This code may be freely distributed and modified under the
 * terms of the GNU Lesser General Public Licence.  This should
 * be distributed with the code.  See the LICENSE file for more
 * information or http://www.gnu.org/copyleft/lesser.html.
 *
 */

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import org.intermine.bio.io.gff3.GFF3Record;
import org.intermine.metadata.Model;
import org.intermine.metadata.StringUtil;
import org.intermine.xml.full.Item;

/**
 * A converter/retriever for the RefseqNoncodingGff dataset via RefSeq GFF files.
 */

public class RefseqNoncodingGffGFF3RecordHandler extends RefseqGffGFF3RecordHandler
{

    /**
     * Create a new RefseqNoncodingGffGFF3RecordHandler for the given data model.
     * @param model the model for which items will be created
     */
    public RefseqNoncodingGffGFF3RecordHandler (Model model) {
        super(model);
        refsAndCollections.put("Exon", "transcripts");
        refsAndCollections.put("Transcript", "gene");
        refsAndCollections.put("PrimaryTranscript", "gene");
        refsAndCollections.put("NcRNA", "gene");
        refsAndCollections.put("MiRNA", "gene");
        refsAndCollections.put("TRNA", "gene");
        refsAndCollections.put("RRNA", "gene");
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void process(GFF3Record record) {
        super.process(record);
        Item feature = getFeature();
        String clsName = feature.getClassName();

        if (clsName.equals("PrimaryTranscript")) {
            setFeatureSymbol(record);
            setFeatureDescription(record);
            createMatureTranscripts(record);
            handleDbxrefs(record, "mirbaseIdentifier", "miRBase");
            handleDbxrefs(record, "primaryIdentifier", "RefSeq_NA");
        } else if (clsName.equals("MiRNA")) {
            setFeatureSymbol(record);
            setFeatureDescription(record);
            handleDbxrefs(record, "primaryIdentifier", "miRBase");
        } else if (clsName.equals("TRNA") || clsName.equals("RRNA")) {
            setFeatureSymbol(record);
            setFeatureDescription(record);
            handleDbxrefs(record, "primaryIdentifier", "RefSeq_NA");
        } else if (clsName.equals("Gene") || clsName.equals("Transcript")) {
            // These were handled in the parent class, nothing more to do here
        } else if (clsName.equals("Exon")) {
            // Do nothing
        } else {
            throw new RuntimeException("Unexpected feature type encountered: " + clsName);
        }
    }   


    /**
     * Create mature transcripts, if applicable.
     * @param record
     */
    protected void createMatureTranscripts(GFF3Record record) {
        Item feature = getFeature();
        if (record.getAttributes().get("mature_form") != null) {
            // mature_form for miRNA
            String matureFormString = record.getAttributes().get("mature_form").iterator().next();
            List<String> entities = new ArrayList<String>(Arrays.asList(StringUtil.split(matureFormString, "|")));

            for (String entity : entities) {
                Item matureTranscriptItem = converter.createItem("MatureTranscript");
                String matureTranscriptItemRefId = matureTranscriptItem.getIdentifier();
                List<String> entityAttributes = new ArrayList<String>(Arrays.asList(StringUtil.split(entity, ",")));
                List<String> locationInformation = new ArrayList<String>(Arrays.asList(StringUtil.split(entityAttributes.get(0), ":")));
                String chromosome = locationInformation.get(0);
                List<String> positionInfo = new ArrayList<String>(Arrays.asList(StringUtil.split(locationInformation.get(1), "..")));
                String start = positionInfo.get(0);
                String end = positionInfo.get(1);
                int strand = locationInformation.get(2).equals("+") ? 1 : -1;
                matureTranscriptItem.setAttribute("chromosome", chromosome);
                matureTranscriptItem.setAttribute("start", start);
                matureTranscriptItem.setAttribute("end", end);
                matureTranscriptItem.setAttribute("strand", Integer.toString(strand));
                String transcriptId = entityAttributes.get(1).split(":")[1];
                String mirbaseId = entityAttributes.get(2).split(":")[1];
                String description = entityAttributes.get(3).split(":")[1];
                matureTranscriptItem.setAttribute("transcriptIdentifier", transcriptId);
                matureTranscriptItem.setAttribute("mirbaseIdentifier", mirbaseId);
                setItemDescription(matureTranscriptItem, description);

                try {
                    converter.store(matureTranscriptItem);
                } catch (Exception e) {
                    System.out.println("Exception while storing matureTranscriptItem:" + matureTranscriptItem + "\n" + e);
                }

                feature.addToCollection("matureTranscripts", matureTranscriptItemRefId);
            }
        }
    }
}
